import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  template: `
   <register-data-in-database></register-data-in-database>
   <div style="text-align:center">
  <h3>
    Welcome to {{title}}!
  </h3>
    
  `,
  styles: []
})
export class AppComponent {
  title = 'LTIExamPortalApp';
}
