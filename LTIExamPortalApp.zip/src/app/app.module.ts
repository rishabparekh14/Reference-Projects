import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { RouterModule }   from '@angular/router';
import { AppComponent } from './app.component';
import { RegisterServiceAddInDatabaseService } from './RegisterStudent/RegisterStudent-service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RegisterFormComponent } from './RegisterStudent/RegisterStudent-form.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterFormComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [RegisterServiceAddInDatabaseService,HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
