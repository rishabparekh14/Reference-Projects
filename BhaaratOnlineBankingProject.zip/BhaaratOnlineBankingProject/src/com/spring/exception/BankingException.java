package com.spring.exception;

public class BankingException extends Exception 
{

	public BankingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
