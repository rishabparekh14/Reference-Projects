package com.spring.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalExceptionHandler
{
	@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception e)
	{
		String view="error";
		ModelAndView model = new ModelAndView(view);
		model.addObject("err", e.getMessage());
		return model;
	}

}
