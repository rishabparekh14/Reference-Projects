package com.spring.service;

import java.util.List;

import com.spring.model.Transaction;
import com.spring.exception.BankingException;
import com.spring.model.Customer;

public interface BankingService 
{
	public boolean addCustomer(Customer c);
	public List<Customer> fetchAllCustomer();
	public Customer findByUsername(String username);
	public double deposit(String username,double amount);
	public double withdraw(String username,double amount);
	public double showBalance(String username);
	public List<Transaction> printTransaction(String username) throws BankingException;
	public String fundTransfer(String username,long targetAccNo,double amount) throws BankingException;
}
