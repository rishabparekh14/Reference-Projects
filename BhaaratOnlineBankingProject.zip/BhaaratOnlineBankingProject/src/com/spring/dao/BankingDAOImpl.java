package com.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.spring.model.Customer;

@Repository
public class BankingDAOImpl implements BankingDAO
{
	@PersistenceContext
	EntityManager manager;

	@Override
	public boolean addCustomer(Customer c) 
	{
		manager.persist(c);
		return true;
	}

	@Override
	public List<Customer> fetchAll() 
	{
		Query query = manager.createQuery("select customer from Customer customer");
		List<Customer> list = query.getResultList();
		
		return list;
	}

	@Override
	public Customer findByUsername(String username) 
	{
		Customer cus = manager.find(Customer.class, username);
		return cus;
	}

}
